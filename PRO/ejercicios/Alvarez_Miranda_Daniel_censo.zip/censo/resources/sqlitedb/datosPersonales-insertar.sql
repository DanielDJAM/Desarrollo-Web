INSERT INTO DatosPersonales(dni, nombre, fecha, id_direccion, tlfn)
  VALUES ("11111111A","Daniel","99/99/99","1001-A123", "333 666 999");